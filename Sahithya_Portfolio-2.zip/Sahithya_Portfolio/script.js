const nav = document.querySelector('.navbar');
const toggle = document.querySelector('.menu-toggle');
toggle.addEventListener('click', () => nav.classList.toggle('nav-open'));

document.querySelectorAll('.navbar nav a').forEach(link => {
  link.addEventListener('click', () => nav.classList.remove('nav-open'));
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
