# Damodarapatruni Sahithya — Personal Portfolio

A responsive personal portfolio website created using HTML, CSS and JavaScript.

## Sections
- Home
- About
- Education
- Skills
- Project
- Internship
- Certifications & Workshops
- Contact

## Technologies
- HTML
- CSS
- JavaScript

## Run locally
Open `index.html` in a web browser.

## Author
Damodarapatruni Sahithya
- LinkedIn: https://www.linkedin.com/in/damodarapatruni-sahithya-754651412
- GitHub: https://github.com/Sahithya85
